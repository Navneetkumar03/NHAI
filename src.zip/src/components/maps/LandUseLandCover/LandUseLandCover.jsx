import { useEffect, useRef, useState, useCallback } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-side-by-side";
import {
  Loader2,
  AlertTriangle,
  Layers,
  X,
  Maximize,
  Minimize,
  CircleDot,
  ChevronDown,
  Calendar,
  Table,
  Map,
  Eye,
  EyeOff,
  Navigation,   // 🆕 add this
} from "lucide-react";
import { useFlyoverData } from "../../../hooks/useFlyoverData";
import { useMovementPoints } from "../../../hooks/useMovementPoints";
import { useFlyoverSegments } from "../../../hooks/useFlyoverSegments";
import { sendUserActivity } from "../../../services/api/auth";
import {
  getFlyoverColor,
  getFlyoverDisplayName,
  makeFlyoverIcon,
  formatPointName,
} from "../shared/mapHelpers";
import MovementPointsChart from "../../charts/MovementPointsChart";
import MovementDiffChart from "../../charts/MovementDiffChart";
import TrafficAnalysisPanel from "../../traffic/TrafficAnalysisPanel";
import { BASE, DEFAULT_CENTER, DEFAULT_ZOOM, LULC_FADE_MS, MAX_ZOOM, MIN_ZOOM, NEUTRAL_FILL, TILE_LAYER_URL, YEARS } from "./constants";
import { DateRangeSelector } from "./controls/DateRangeSelector";
import { FullscreenButton } from "./controls/FullscreenButton";
import { LayerSelector } from "./controls/LayerSelector";
import { YearSelect } from "./controls/YearSelect";
import { LULCLegend } from "./legends/LULCLegend";
import { RiskLegend } from "./legends/RiskLegend";
import { SoilLegend } from "./legends/SoilLegend";
import { VelocityDiffLegend } from "./legends/VelocityDiffLegend";
import { VelocityLegend } from "./legends/VelocityLegend";
import { addAllToMap, escapeHtml, getDiffRestingCircleStyle, getHoverCircleStyle, getRestingCircleStyle, getSelectedCircleStyle, getVelocityColor, getWeightForZoom, log, logError, onEachSoilFeature, removeAllFromMap, soilStyle } from "./mapUtils";
import { RiskOverviewPanel } from "./panels/RiskOverviewPanel";
import { SegmentTable } from "./panels/SegmentTable";

export function LandUseLandCover({
  mapCenter = DEFAULT_CENTER,
  defaultLeftYear = YEARS[0],
  defaultRightYear = YEARS[YEARS.length - 1],
  className = "",
  isActive = true,
}) {
  /* ---------------- Refs --------------- */

  const mapContainerRef = useRef(null);
  const fullscreenContainerRef = useRef(null);

  const zoomControlContainerRef = useRef(null);
  const layerControlWrapperRef = useRef(null);

  const mapRef = useRef(null);
  const leftLayerRef = useRef(null);
  const rightLayerRef = useRef(null);
  const sideBySideRef = useRef(null);

  const lulcCreatedRef = useRef(false);

  const streetLayerRef = useRef(null);
  const satelliteLayerRef = useRef(null);
  const esriSatelliteLayerRef = useRef(null);

  const soilLayerRef = useRef(null);
  const soilDataRef = useRef(null);
  const hasFitSoilBoundsRef = useRef(false);

  const flyoverLayersRef = useRef([]);
  const flyoverMarkersRef = useRef([]);
  const movementMarkersRef = useRef([]);

  // 🆕 Difference-mode circles share the same L.circle / zoom-weight approach
  // as velocity mode, so they're tracked here for both zoom updates and
  // cleanup.
  const diffMarkersRef = useRef([]);

  const selectedMovementMarkerRef = useRef(null);

  const liveSegmentLayerRef = useRef(null);
  const polygonSegmentLayerRef = useRef(null);
  const selectedPolygonLayerRef = useRef(null);
  const segmentHighlightLayerRef = useRef(null);

  const tagRef = useRef(null);
  const dividerLineRef = useRef(null);
  const rafIdRef = useRef(null);
  const debounceRef = useRef(null);
  const dividerReadyTimeoutRef = useRef(null);

  const resizeObserverRef = useRef(null);

  const isMountedRef = useRef(true);
  const isMapReadyRef = useRef(false);
  const hasFitBoundsRef = useRef(false);

  const flyoverButtonsContainerRef = useRef(null);
  const flyoverBoundsRef = useRef([]); // [{ id, name, bounds, layers, markers }]

  /* 🆕 GPS refs */
  const userLocationMarkerRef = useRef(null);
  const userAccuracyCircleRef = useRef(null);
  const hasAutoCenteredOnUserRef = useRef(false);

  /* ---------------- State ---------------- */
  const [activeFlyoverId, setActiveFlyoverId] = useState(null);

  const [showChart, setShowChart] = useState(false);
  const [selectedPointForChart, setSelectedPointForChart] = useState(null);
  const [selectedDetailForChart, setSelectedDetailForChart] = useState(null);

  const [showDiffChart, setShowDiffChart] = useState(false);
  const [diffPointData, setDiffPointData] = useState(null);
  const [diffDetailData, setDiffDetailData] = useState(null);
  const [diffStartDate, setDiffStartDate] = useState("");
  const [diffEndDate, setDiffEndDate] = useState("");

  const [selectedLayer, setSelectedLayer] = useState("velocity");

  const [yearLeft, setYearLeft] = useState(defaultLeftYear);
  const [yearRight, setYearRight] = useState(defaultRightYear);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [isDividerReady, setIsDividerReady] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1024);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLayerPanelOpen, setIsLayerPanelOpen] = useState(false);

  const [activeLayers, setActiveLayers] = useState(["linear", "movement"]);
  const [baseLayer, setBaseLayer] = useState("streets");

  const [showLULC, setShowLULC] = useState(false);
  const [showSoil, setShowSoil] = useState(false);

  const [soilData, setSoilData] = useState(null);
  const [soilLoading, setSoilLoading] = useState(true);
  const [soilError, setSoilError] = useState(null);
  const [taxoValues, setTaxoValues] = useState([]);

  const [selectedSegmentId, setSelectedSegmentId] = useState(null);
  const [segmentData, setSegmentData] = useState([]);
  const [segmentLoading, setSegmentLoading] = useState(false);
  const [polygonLoading, setPolygonLoading] = useState(false);
  const [showSegmentTable, setShowSegmentTable] = useState(false);
  const [showSegmentLegend, setShowSegmentLegend] = useState(false);
  const [showLinearLayer, setShowLinearLayer] = useState(false);

  const [showOverview, setShowOverview] = useState(true);
  const [flyoverEntries, setFlyoverEntries] = useState([]);

  /* ---------------- Google Traffic ---------------- */

  const [showTrafficPanel, setShowTrafficPanel] = useState(false);
  const [selectedFlyoverForTraffic, setSelectedFlyoverForTraffic] = useState(null);

  /* 🆕 GPS state */
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState(null);

  /* ---------------- Data hooks ---------------- */

  const { flyovers, loading: flyoversLoading } = useFlyoverData();

  const {
    points: movementPoints,
    loading: movementLoading,
    error: movementError,
    availableDates,
    selectPoint,
    velocityDiff,
    velocityDiffRange,
    velocityDiffLoading,
    velocityDiffError,
    loadVelocityDiff,
    clearVelocityDiff,
  } = useMovementPoints();

  const {
    liveSegments,
    polygonSegments,
    segmentStats,
    loading: segmentsLoading,
    error: segmentsError,
    loadLiveSegments,
    loadPolygonSegment,
    loadSegmentStats,
    getVelocityColor: getSegVelocityColor,
  } = useFlyoverSegments();

  const availableLayers = [
    { id: "linear", name: "Assets", color: "#8B5CF6", type: "overlay" },
    // { id: "flyover", name: "Flyover", color: "#3B82F6", type: "overlay" },
    { id: "lulc", name: "LULC", color: "#10B981", type: "overlay" },
    { id: "soil", name: "Soil", color: "#8B5E3C", type: "overlay" },
  ];

  const showDifferenceUI = selectedLayer === "difference";
  const showVelocityUI = selectedLayer === "velocity";
  const showSegmentsUI = activeLayers.includes("linear");

  /* ==========================================================================
   * SEGMENT FUNCTIONS
   * ========================================================================*/

  const addPolygonHighlight = useCallback((map, polygonData) => {
    if (
      !polygonData ||
      !polygonData.features ||
      polygonData.features.length === 0
    ) {
      if (
        selectedPolygonLayerRef.current &&
        map.hasLayer(selectedPolygonLayerRef.current)
      ) {
        map.removeLayer(selectedPolygonLayerRef.current);
        selectedPolygonLayerRef.current = null;
      }
      return;
    }

    if (
      selectedPolygonLayerRef.current &&
      map.hasLayer(selectedPolygonLayerRef.current)
    ) {
      map.removeLayer(selectedPolygonLayerRef.current);
    }

    selectedPolygonLayerRef.current = L.geoJSON(polygonData, {
      style: {
        color: "#ff6b6b",
        weight: 4,
        opacity: 1,
        fillColor: "#ff6b6b",
        fillOpacity: 0.3,
        dashArray: "5, 5",
      },
      onEachFeature: (feature, layer) => {
        const props = feature?.properties || {};
        const velocity = props.avg_velocity;

        layer.bindPopup(`
          <div style="padding: 8px; font-family: Arial, sans-serif; min-width: 180px;">
            <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 14px; font-weight: 600; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px;">
              ${props.name || "Unknown Polygon Segment"}
            </h4>
            <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
              <tr>
                <td style="padding: 2px 0; color: #6b7280;">ID:</td>
                <td style="padding: 2px 0; font-weight: 600;">${props.objectid || "N/A"}</td>
              </tr>
              <tr>
                <td style="padding: 2px 0; color: #6b7280;">Type:</td>
                <td style="padding: 2px 0; font-weight: 600;">Polygon</td>
              </tr>
              <tr>
                <td style="padding: 2px 0; color: #6b7280;">Velocity:</td>
                <td style="padding: 2px 0; font-weight: 600; color: #2563eb;">
                  ${velocity !== null && velocity !== undefined ? velocity + " mm/yr" : "N/A"}
                </td>
              </tr>
              ${props.insert_at
            ? `
              <tr>
                <td style="padding: 2px 0; color: #6b7280;">Updated:</td>
                <td style="padding: 2px 0; font-weight: 600; font-size: 10px;">${new Date(props.insert_at).toLocaleString()}</td>
              </tr>
              `
            : ""
          }
            </table>
          </div>
        `);
      },
    }).addTo(map);

    selectedPolygonLayerRef.current.setZIndex(450);

    try {
      const bounds = selectedPolygonLayerRef.current.getBounds();
      if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50] });
      }
    } catch (err) {
      console.warn("Could not fit to polygon bounds:", err);
    }
  }, []);

  const handleSegmentRowClick = useCallback(
    async (id) => {
      if (!id) return;

      setSelectedSegmentId(id);
      setPolygonLoading(true);

      try {
        const polygonData = await loadPolygonSegment({
          type: "id",
          id: String(id),
        });

        if (
          polygonData &&
          polygonData.features &&
          polygonData.features.length > 0
        ) {
          if (mapRef.current) {
            addPolygonHighlight(mapRef.current, polygonData);
          }
        } else {
          if (mapRef.current) {
            addPolygonHighlight(mapRef.current, null);
          }
        }
      } catch (err) {
        console.error("Error loading polygon segment:", err);
      } finally {
        setPolygonLoading(false);
      }
    },
    [loadPolygonSegment, addPolygonHighlight],
  );

  const addLiveSegmentLayer = useCallback(
    (map) => {
      if (
        !liveSegments ||
        !liveSegments.features ||
        liveSegments.features.length === 0
      ) {
        console.log("No live segments data to display");
        return;
      }

      if (
        liveSegmentLayerRef.current &&
        map.hasLayer(liveSegmentLayerRef.current)
      ) {
        map.removeLayer(liveSegmentLayerRef.current);
        liveSegmentLayerRef.current = null;
      }

      console.log(
        `Adding ${liveSegments.features.length} segment features to map`,
      );

      const getRiskColor = (risk) => {
        switch (risk) {
          case 1:
            return "#3B82F6";
          case 2:
            return "#63A0F0";
          case 3:
            return "#F97316";
          case 4:
            return "#EA580C";
          case 5:
            return "#EF4444";
          default:
            return "#64748b";
        }
      };

      liveSegmentLayerRef.current = L.geoJSON(liveSegments, {
        style: (feature) => {
          const risk = feature?.properties.risk;
          return {
            color: getRiskColor(risk),
            weight: 7,
            opacity: 0.9,
            lineCap: "round",
            lineJoin: "round",
          };
        },
        filter: (feature) => {
          return feature?.geometry?.type === "LineString";
        },
        onEachFeature: (feature, layer) => {
          const props = feature?.properties || {};
          const velocity = props.avg_velocity;

          if (feature?.geometry?.type !== "LineString") {
            return;
          }

          layer.bindPopup(`
        <div style="padding: 8px; font-family: Arial, sans-serif; min-width: 180px;">
          <h4 style="margin: 0 0 6px 0; color: #1f2937; font-size: 14px; font-weight: 600; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px;">
            ${props.name || "Unknown Segment"}
          </h4>
          <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
            <tr>
              <td style="padding: 2px 0; color: #6b7280;">ID:</td>
              <td style="padding: 2px 0; font-weight: 600;">${props.objectid || "N/A"}</td>
            </tr>
            <tr>
              <td style="padding: 2px 0; color: #6b7280;">Velocity:</td>
              <td style="padding: 2px 0; font-weight: 600; color: #2563eb;">
                ${velocity !== null && velocity !== undefined ? velocity + " mm/yr" : "N/A"}
              </td>
            </tr>
            <tr>
              <td style="padding: 2px 0; color: #6b7280;">Risk:</td>
              <td style="padding: 2px 0; font-weight: 600;">${props.risk || "N/A"}</td>
            </tr>
            ${props.insert_at
              ? `
            <tr>
              <td style="padding: 2px 0; color: #6b7280;">Updated:</td>
              <td style="padding: 2px 0; font-weight: 600; font-size: 10px;">${new Date(props.insert_at).toLocaleString()}</td>
            </tr>
            `
              : ""
            }
          </table>
        </div>
      `);

          layer.on({
            mouseover: (e) => {
              const layer = e.target;
              layer.setStyle({ weight: 9, opacity: 1, color: "#ffff00" });
              layer.openPopup();
            },
            mouseout: (e) => {
              const layer = e.target;
              const risk = feature?.properties?.risk;
              layer.setStyle({
                color: getRiskColor(risk),
                weight: 7,
                opacity: 0.9,
              });
              layer.closePopup();
            },
          });
        },
      }).addTo(map);

      liveSegmentLayerRef.current.setZIndex(400);
    },
    [liveSegments, handleSegmentRowClick],
  );

  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;
    if (!showSegmentsUI) {
      if (
        liveSegmentLayerRef.current &&
        mapRef.current.hasLayer(liveSegmentLayerRef.current)
      ) {
        mapRef.current.removeLayer(liveSegmentLayerRef.current);
        liveSegmentLayerRef.current = null;
      }
      return;
    }

    const timeoutId = setTimeout(() => {
      try {
        addLiveSegmentLayer(mapRef.current);
      } catch (err) {
        logError("[LULC] Error adding segment layer:", err);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [showSegmentsUI, liveSegments, addLiveSegmentLayer]);

  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;
    if (!selectedSegmentId || !showSegmentsUI) {
      if (
        selectedPolygonLayerRef.current &&
        mapRef.current.hasLayer(selectedPolygonLayerRef.current)
      ) {
        mapRef.current.removeLayer(selectedPolygonLayerRef.current);
        selectedPolygonLayerRef.current = null;
      }
      return;
    }
  }, [selectedSegmentId, showSegmentsUI]);

  useEffect(() => {
    if (showSegmentsUI && segmentData.length === 0 && !segmentLoading) {
      setSegmentLoading(true);

      loadSegmentStats().then((data) => {
        if (data) {
          const extractedData = data.map((item) => ({
            id: item?.id || 0,
            name: item?.name || "NH 152 Ambala",
            risk: item?.risk ?? null,
            avg_velocity:
              item?.avg_velocity !== undefined && item?.avg_velocity !== null
                ? parseFloat(item.avg_velocity)
                : null,
            point_count: item?.point_count || 0,
          }));
          setSegmentData(extractedData);
        }
        setSegmentLoading(false);
      });
    }
  }, [showSegmentsUI, segmentData.length, segmentLoading, loadSegmentStats]);

  /* ==========================================================================
   * MOVEMENT POINTS (velocity mode)
   * ========================================================================*/

  const updateCircleWeights = useCallback(() => {
    if (!mapRef.current) return;
    const zoom = mapRef.current.getZoom();
    const weight = getWeightForZoom(zoom);
    movementMarkersRef.current.forEach((marker) => {
      marker.options.weight = weight;
      marker.setStyle({ weight });
    });
    // 🆕 Difference circles also scale with zoom
    diffMarkersRef.current.forEach((marker) => {
      marker.options.weight = weight;
      marker.setStyle({ weight });
    });
  }, []);

  const addMovementPointsToMap = useCallback(
    (map, points) => {
      if (!points || points.length === 0) {
        return;
      }

      removeAllFromMap(map, movementMarkersRef.current);
      movementMarkersRef.current = [];

      selectedMovementMarkerRef.current = null;

      points.forEach((feature) => {
        const { id, longitude, latitude, velocity } = feature.data;

        const circle = L.circle([latitude, longitude], {
          pane: "movementPane",
          radius: 4,
          ...getRestingCircleStyle(selectedLayer, velocity, map.getZoom()),
        });

        circle._movementVelocity = velocity;
        circle._movementId = id;

        circle.on("mouseover", function () {
          if (selectedMovementMarkerRef.current === this) {
            this.setStyle(getSelectedCircleStyle(map.getZoom()));
          } else {
            this.setStyle(getHoverCircleStyle(map.getZoom()));
          }
          // Point ID: ${ escapeHtml(id) } <br />
          if (selectedLayer === "velocity") {
            const tooltipContent = `
                  <div style="padding: 2px 6px; font-size: 12px; font-weight: 600; line-height: 1.3;">
                    
                    Velocity: ${escapeHtml(velocity)} mm/yr
                  </div>
                `;
            this.bindTooltip(tooltipContent, {
              permanent: false,
              direction: "top",
              offset: [0, -10],
              className: "velocity-tooltip",
            }).openTooltip();
          } else {
            this.closeTooltip();
          }
        });

        circle.on("mouseout", function () {
          if (selectedMovementMarkerRef.current === this) {
            this.setStyle(getSelectedCircleStyle(map.getZoom()));
          } else {
            this.setStyle(
              getRestingCircleStyle(
                selectedLayer,
                this._movementVelocity,
                map.getZoom(),
              ),
            );
          }

          this.closeTooltip();
        });

        circle.on("click", async function () {
          if (selectedLayer === "none") {
            return;
          }

          if (selectedMovementMarkerRef.current === this) {
            this.setStyle(
              getRestingCircleStyle(
                selectedLayer,
                this._movementVelocity,
                map.getZoom(),
              ),
            );

            selectedMovementMarkerRef.current = null;

            setShowChart(false);
            setShowDiffChart(false);

            return;
          }
          // Capture actual velocity point click
          sendUserActivity(
            `Clicked Velocity Point: ${id} (${velocity} mm/yr)`,
            "InfraRisk",
          );

          if (selectedMovementMarkerRef.current) {
            const previousMarker = selectedMovementMarkerRef.current;

            previousMarker.setStyle(
              getRestingCircleStyle(
                selectedLayer,
                previousMarker._movementVelocity,
                map.getZoom(),
              ),
            );
          }

          selectedMovementMarkerRef.current = this;

          this.setStyle(getSelectedCircleStyle(map.getZoom()));

          try {
            const detailData = await selectPoint(id);

            if (detailData) {
              if (
                selectedLayer === "difference" &&
                diffStartDate &&
                diffEndDate
              ) {
                setDiffPointData(feature);
                setDiffDetailData(detailData);
                setShowDiffChart(true);
              } else {
                setSelectedPointForChart(feature);
                setSelectedDetailForChart(detailData);
                setShowChart(true);
              }
            }
          } catch (err) {
            logError("Error fetching point details:", err);
          }
        });

        movementMarkersRef.current.push(circle);
      });

      // In difference mode, the diff circles (below) replace these — don't
      // attach the velocity-styled circles.
      if (selectedLayer === "velocity") {
        movementMarkersRef.current.forEach((marker) => marker.addTo(map));
        updateCircleWeights();
      }
    },
    [
      selectedLayer,
      selectPoint,
      diffStartDate,
      diffEndDate,
      updateCircleWeights,
    ],
  );

  const updateMovementVisibility = useCallback(() => {
    if (!mapRef.current) return;

    if (selectedLayer === "velocity") {
      addAllToMap(mapRef.current, movementMarkersRef.current);
      removeAllFromMap(mapRef.current, diffMarkersRef.current);
    } else if (selectedLayer === "difference") {
      removeAllFromMap(mapRef.current, movementMarkersRef.current);
      addAllToMap(mapRef.current, diffMarkersRef.current);
    } else {
      removeAllFromMap(mapRef.current, movementMarkersRef.current);
      removeAllFromMap(mapRef.current, diffMarkersRef.current);
    }
  }, [selectedLayer]);

  /* ==========================================================================
   * DIFFERENCE-MODE CIRCLES  🆕
   * Uses L.circle (same as velocity) so circles scale with zoom via
   * updateCircleWeights(). Colors come from feature.properties.color.
   * Hover shows a tooltip. Click opens the diff chart.
   * ========================================================================*/

  const addDiffPointsToMap = useCallback(
    (map, geojsonData) => {
      if (
        !geojsonData ||
        !geojsonData.features ||
        geojsonData.features.length === 0
      ) {
        return;
      }

      // Wipe any previous diff circles
      removeAllFromMap(map, diffMarkersRef.current);
      diffMarkersRef.current = [];

      geojsonData.features.forEach((feature) => {
        const p = feature?.properties || {};
        const lat = p.latitude;
        const lng = p.longitude;
        if (typeof lat !== "number" || typeof lng !== "number") return;

        const id = p.id;
        const velocity = p.velocity;
        const diff = p.diff;
        const color = p.color || NEUTRAL_FILL;

        const circle = L.circle([lat, lng], {
          pane: "movementPane",
          radius: 4,
          ...getDiffRestingCircleStyle(color, map.getZoom()),
        });

        circle._movementVelocity = velocity;
        circle._movementId = id;
        circle._movementDiff = diff;
        circle._movementColor = color;
        circle._movementFeature = feature;

        circle.on("mouseover", function () {
          // Keep the selected point yellow regardless of hover
          if (selectedMovementMarkerRef.current === this) {
            this.setStyle(getSelectedCircleStyle(map.getZoom()));
          } else {
            this.setStyle(getHoverCircleStyle(map.getZoom()));
          }

          // 🆕 Tooltip on hover, same pattern as velocity mode
          const tooltipContent = `
            <div style="padding: 2px 6px; font-size: 12px; font-weight: 600; line-height: 1.3;">
              Diff: ${escapeHtml(diff)} mm
            </div>
          `;
          this.bindTooltip(tooltipContent, {
            permanent: false,
            direction: "top",
            offset: [0, -10],
            className: "velocity-tooltip",
          }).openTooltip();
        });

        circle.on("mouseout", function () {
          if (selectedMovementMarkerRef.current === this) {
            this.setStyle(getSelectedCircleStyle(map.getZoom()));
          } else {
            this.setStyle(
              getDiffRestingCircleStyle(this._movementColor, map.getZoom()),
            );
          }
          this.closeTooltip();
        });

        circle.on("click", async function () {
          // Toggle off if already selected
          if (selectedMovementMarkerRef.current === this) {
            this.setStyle(
              getDiffRestingCircleStyle(this._movementColor, map.getZoom()),
            );
            selectedMovementMarkerRef.current = null;
            setShowChart(false);
            setShowDiffChart(false);
            return;
          }

          // Restore previous selection to its diff color
          if (selectedMovementMarkerRef.current) {
            const prev = selectedMovementMarkerRef.current;
            prev.setStyle(
              getDiffRestingCircleStyle(prev._movementColor, map.getZoom()),
            );
          }

          // Highlight this one
          selectedMovementMarkerRef.current = this;
          this.setStyle(getSelectedCircleStyle(map.getZoom()));

          // 🆕 Open the difference chart for this point
          try {
            const detailData = await selectPoint(id);

            if (detailData) {
              if (
                selectedLayer === "difference" &&
                diffStartDate &&
                diffEndDate
              ) {
                setDiffPointData(feature);
                setDiffDetailData(detailData);
                setShowDiffChart(true);
              } else {
                setSelectedPointForChart(feature);
                setSelectedDetailForChart(detailData);
                setShowChart(true);
              }
            }
          } catch (err) {
            logError("Error fetching diff point details:", err);
          }
        });

        diffMarkersRef.current.push(circle);
      });

      // Attach only if we're currently in difference mode
      if (selectedLayer === "difference") {
        diffMarkersRef.current.forEach((m) => m.addTo(map));
        updateCircleWeights();
      }
    },
    [
      selectedLayer,
      selectPoint,
      diffStartDate,
      diffEndDate,
      updateCircleWeights,
    ],
  );

  // Fetch + render diff when in Difference mode with valid dates.
  // Tear down and clear when leaving Difference mode.
  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;

    if (selectedLayer !== "difference") {
      removeAllFromMap(mapRef.current, diffMarkersRef.current);
      diffMarkersRef.current = [];
      clearVelocityDiff();
      return;
    }

    if (!diffStartDate || !diffEndDate) {
      return;
    }

    let cancelled = false;

    (async () => {
      const result = await loadVelocityDiff(diffStartDate, diffEndDate);
      if (cancelled) return;
      if (!result?.data) return;
      if (!mapRef.current || !isMapReadyRef.current) return;

      addDiffPointsToMap(mapRef.current, result.data);
    })();

    return () => {
      cancelled = true;
    };
  }, [
    selectedLayer,
    diffStartDate,
    diffEndDate,
    loadVelocityDiff,
    clearVelocityDiff,
    addDiffPointsToMap,
  ]);

  // If the diff data reference changes while still in Difference mode,
  // re-render the circles (e.g. cache hit after switching back).
  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;
    if (selectedLayer !== "difference") return;
    if (!velocityDiff) return;

    if (
      diffMarkersRef.current.length === 0 ||
      (diffMarkersRef.current.length > 0 &&
        !mapRef.current.hasLayer(diffMarkersRef.current[0]))
    ) {
      addDiffPointsToMap(mapRef.current, velocityDiff);
    }
  }, [selectedLayer, velocityDiff, addDiffPointsToMap]);

  /* ==========================================================================
   * SIDE-BY-SIDE TILE COMPARISON
   * ========================================================================*/

  const handleDividerMove = useCallback(() => {
    if (rafIdRef.current) return;
    rafIdRef.current = requestAnimationFrame(() => {
      rafIdRef.current = null;
      if (!sideBySideRef.current) {
        return;
      }
      const pos = sideBySideRef.current.getPosition();
      const px = `${pos}px`;
      if (tagRef.current) {
        tagRef.current.style.left = px;
      }
      if (dividerLineRef.current) {
        dividerLineRef.current.style.left = px;
      }
    });
  }, []);

  const ensureLULCLayersExist = useCallback(() => {
    if (!mapRef.current || lulcCreatedRef.current) {
      return;
    }

    const map = mapRef.current;

    const leftLayer = L.tileLayer(TILE_LAYER_URL.replace("{year}", yearLeft), {
      tileSize: 256,
      minZoom: MIN_ZOOM,
      maxZoom: MAX_ZOOM,
      crossOrigin: true,
      opacity: 0,
      zIndex: 10,
    });

    const rightLayer = L.tileLayer(
      TILE_LAYER_URL.replace("{year}", yearRight),
      {
        tileSize: 256,
        minZoom: MIN_ZOOM,
        maxZoom: MAX_ZOOM,
        crossOrigin: true,
        opacity: 0,
        zIndex: 10,
      },
    );

    leftLayer.addTo(map);
    rightLayer.addTo(map);

    const sideBySide = L.control
      .sideBySide([leftLayer], [rightLayer])
      .addTo(map);

    sideBySide.setPosition(0.5);
    sideBySide.on("dividermove", handleDividerMove);

    const controlEl = sideBySide._container;

    if (controlEl) {
      controlEl.style.transition = `opacity ${LULC_FADE_MS}ms ease`;
      controlEl.style.opacity = "0";
      controlEl.style.pointerEvents = "none";
    }

    leftLayerRef.current = leftLayer;
    rightLayerRef.current = rightLayer;
    sideBySideRef.current = sideBySide;
    lulcCreatedRef.current = true;

    requestAnimationFrame(() => requestAnimationFrame(handleDividerMove));

    if (!hasFitBoundsRef.current) {
      const bounds = map.getBounds();
      if (bounds.isValid()) {
        map.fitBounds(bounds);
        hasFitBoundsRef.current = true;
      }
    }

    setIsDividerReady(true);
  }, [yearLeft, yearRight, handleDividerMove]);

  const teardownLULCLayers = useCallback(() => {
    if (!mapRef.current) {
      return;
    }

    if (sideBySideRef.current) {
      mapRef.current.removeControl(sideBySideRef.current);
      sideBySideRef.current = null;
    }

    if (leftLayerRef.current && mapRef.current.hasLayer(leftLayerRef.current)) {
      mapRef.current.removeLayer(leftLayerRef.current);
    }

    if (
      rightLayerRef.current &&
      mapRef.current.hasLayer(rightLayerRef.current)
    ) {
      mapRef.current.removeLayer(rightLayerRef.current);
    }

    leftLayerRef.current = null;
    rightLayerRef.current = null;
    lulcCreatedRef.current = false;
    setIsDividerReady(false);
  }, []);

  /* ==========================================================================
   * FLYOVER LAYERS
   * ========================================================================*/

  const updateLayerVisibility = useCallback(() => {
    if (!mapRef.current) {
      return;
    }

    // 🆕 Flyover pins now follow the Assets (linear) toggle instead of the
    // now-hidden Flyover entry.
    if (activeLayers.includes("linear")) {
      addAllToMap(mapRef.current, flyoverLayersRef.current);
      addAllToMap(mapRef.current, flyoverMarkersRef.current);
    } else {
      removeAllFromMap(mapRef.current, flyoverLayersRef.current);
      removeAllFromMap(mapRef.current, flyoverMarkersRef.current);
    }
  }, [activeLayers]);







  // const addFlyoverLayers = useCallback(
  //   (map) => {
  //     if (!flyovers || flyovers.length === 0) {
  //       return;
  //     }

  //     try {
  //       requestAnimationFrame(() => {
  //         removeAllFromMap(map, flyoverLayersRef.current);
  //         flyoverLayersRef.current = [];
  //         removeAllFromMap(map, flyoverMarkersRef.current);
  //         flyoverMarkersRef.current = [];

  //         // 🆕 Reset per-flyover metadata
  //         flyoverBoundsRef.current = [];

  //         // 🆕 Mirror the reset into state so the buttons disappear while rebuilding
  //         setFlyoverEntries([]);

  //         flyovers.forEach((flyover, index) => {
  //           try {
  //             const color = getFlyoverColor(index);

  //             // 🆕 Use the same name that appears on the map icon (first named
  //             // point). Falls back to flyover.name / generic display name.
  //             const firstPointName =
  //               flyover.namedPoints && flyover.namedPoints.length > 0
  //                 ? formatPointName(flyover.namedPoints[0].name)
  //                 : null;

  //             // 🆕 Track layers + markers for this specific flyover so we can
  //             // highlight/zoom only this one.
  //             const thisFlyover = {
  //               id: flyover.id ?? index,
  //               name:
  //                 firstPointName ||
  //                 flyover.name ||
  //                 getFlyoverDisplayName(flyover.type, index),
  //               color,
  //               layers: [],
  //               markers: [],
  //               bounds: null,
  //             };

  //             if (flyover.namedPoints && flyover.namedPoints.length > 0) {
  //               flyover.namedPoints.forEach((point) => {
  //                 try {
  //                   const pointName = formatPointName(point.name);
  //                   const icon = makeFlyoverIcon({
  //                     color,
  //                     labelText: pointName,
  //                     detailed: false,
  //                     name: pointName,
  //                     detailFields: [],
  //                   });

  //                   const marker = L.marker(point.latlng, {
  //                     icon,
  //                     riseOnHover: true,
  //                     zIndexOffset: 100,
  //                   });

  //                   const popupContent = `
  //                     <div style="padding: 8px; font-family: Arial, sans-serif;">
  //                       <h4 style="margin: 0 0 4px 0; color: ${escapeHtml(
  //                     color,
  //                   )};">
  //                         ${escapeHtml(pointName)}
  //                       </h4>
  //                       ${point.chainage
  //                       ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Chainage:</strong> ${escapeHtml(
  //                         point.chainage,
  //                       )}</p>`
  //                       : ""
  //                     }
  //                       ${point.description
  //                       ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Type:</strong> ${escapeHtml(
  //                         point.description,
  //                       )}</p>`
  //                       : ""
  //                     }
  //                       ${point.length
  //                       ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Length:</strong> ${escapeHtml(
  //                         point.length,
  //                       )}</p>`
  //                       : ""
  //                     }
  //                       ${point.detail
  //                       ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Structure:</strong> ${escapeHtml(
  //                         point.detail,
  //                       )}</p>`
  //                       : ""
  //                     }
  //                     </div>
  //                   `;

  //                   marker.bindPopup(popupContent, {
  //                     maxWidth: 300,
  //                     autoPan: true,
  //                   });

  //                   flyoverMarkersRef.current.push(marker);
  //                   thisFlyover.markers.push(marker);
  //                 } catch (err) {
  //                   logError(
  //                     `[LULC] Error adding marker for ${point.name}:`,
  //                     err,
  //                   );
  //                 }
  //               });
  //             }

  //             // 🆕 Compute combined bounds for this flyover
  //             try {
  //               const group = L.featureGroup([
  //                 ...thisFlyover.layers,
  //                 ...thisFlyover.markers,
  //               ]);
  //               const b = group.getBounds();
  //               if (b && b.isValid()) {
  //                 thisFlyover.bounds = b;
  //               }
  //             } catch (err) {
  //               logError(
  //                 `[LULC] Could not compute bounds for ${thisFlyover.name}:`,
  //                 err,
  //               );
  //             }

  //             flyoverBoundsRef.current.push(thisFlyover);
  //           } catch (err) {
  //             logError(`[LULC] Error processing flyover ${index}:`, err);
  //           }
  //         });

  //         // 🆕 Mirror the populated ref into state so React re-renders the
  //         // flyover buttons by default (no user interaction required).
  //         setFlyoverEntries([...flyoverBoundsRef.current]);

  //         updateLayerVisibility();

  //         // 🆕 Force re-render of flyover buttons
  //         setActiveFlyoverId((prev) => prev);
  //       });
  //     } catch (err) {
  //       logError("[LULC] Error in addFlyoverLayers:", err);
  //     }
  //   },
  //   [flyovers, updateLayerVisibility],
  // );



  const addFlyoverLayers = useCallback(
    (map) => {
      if (!flyovers || flyovers.length === 0) {
        return;
      }

      try {
        requestAnimationFrame(() => {
          removeAllFromMap(map, flyoverLayersRef.current);
          flyoverLayersRef.current = [];
          removeAllFromMap(map, flyoverMarkersRef.current);
          flyoverMarkersRef.current = [];

          // 🆕 Reset per-flyover metadata
          flyoverBoundsRef.current = [];

          // 🆕 Mirror the reset into state so the buttons disappear while rebuilding
          setFlyoverEntries([]);

          flyovers.forEach((flyover, index) => {
            try {
              const color = getFlyoverColor(index);

              // 🆕 Use the same name that appears on the map icon (first named
              // point). Falls back to flyover.name / generic display name.
              const firstPointName =
                flyover.namedPoints && flyover.namedPoints.length > 0
                  ? formatPointName(flyover.namedPoints[0].name)
                  : null;

              // 🆕 Track layers + markers for this specific flyover so we can
              // highlight/zoom only this one.
              const thisFlyover = {
                id: flyover.id ?? index,
                name:
                  firstPointName ||
                  flyover.name ||
                  getFlyoverDisplayName(flyover.type, index),
                color,
                layers: [],
                markers: [],
                bounds: null,
              };

              if (flyover.namedPoints && flyover.namedPoints.length > 0) {
                flyover.namedPoints.forEach((point) => {
                  try {
                    const pointName = formatPointName(point.name);
                    const icon = makeFlyoverIcon({
                      color,
                      labelText: pointName,
                      detailed: false,
                      name: pointName,
                      detailFields: [],
                    });

                    const marker = L.marker(point.latlng, {
                      icon,
                      riseOnHover: true,
                      zIndexOffset: 100,
                    });

                    const popupContent = `
                      <div style="padding: 8px; font-family: Arial, sans-serif;">
                        <h4 style="margin: 0 0 4px 0; color: ${escapeHtml(
                      color,
                    )};">
                          ${escapeHtml(pointName)}
                        </h4>
                        ${point.chainage
                        ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Chainage:</strong> ${escapeHtml(
                          point.chainage,
                        )}</p>`
                        : ""
                      }
                        ${point.description
                        ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Type:</strong> ${escapeHtml(
                          point.description,
                        )}</p>`
                        : ""
                      }
                        ${point.length
                        ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Length:</strong> ${escapeHtml(
                          point.length,
                        )}</p>`
                        : ""
                      }
                        ${point.detail
                        ? `<p style="margin: 2px 0; font-size: 11px;"><strong>Structure:</strong> ${escapeHtml(
                          point.detail,
                        )}</p>`
                        : ""
                      }
                      </div>
                    `;

                    marker.bindPopup(popupContent, {
                      maxWidth: 300,
                      autoPan: true,
                    });

                    // 🆕 Click handler — opens TrafficAnalysisPanel on the right
                    // side (same slot previously used by RiskOverviewPanel).
                    // marker.on("click", () => {
                    //   // Keep the flyover name format identical to
                    //   // GoogleMapComponent so useTrafficData resolves the
                    //   // correct backend record.
                    //   console.log("clicked flyover id is:", flyover.id)
                    //   const flyoverName = `FLYOVER ${flyover.id ?? index}`;

                    //   // Close competing right-side panels so they don't stack
                    //   setShowOverview(false);
                    //   setShowSegmentTable(false);
                    //   setShowChart(false);
                    //   setShowDiffChart(false);
                    //   setShowTrafficPanel(false);

                    //   // Small delay lets the previous panel unmount cleanly
                    //   // before the new one mounts in the same slot.
                    //   setTimeout(() => {
                    //     setSelectedFlyoverForTraffic(flyoverName);
                    //     setShowTrafficPanel(true);
                    //   }, 0);

                    //   // Highlight the matching quick-jump button
                    //   setActiveFlyoverId(flyover.id ?? index);

                    //   // Pan + zoom to the clicked marker
                    //   if (mapRef.current) {
                    //     mapRef.current.panTo(point.latlng);
                    //     setTimeout(() => {
                    //       mapRef.current?.setZoom(14);
                    //     }, 400);
                    //   }
                    // });


                    marker.on("click", () => {
                      // Backend still expects "FLYOVER N" — keep that format for the API call.
                      const backendName = `FLYOVER ${flyover.id ?? index}`;
                      // Friendly name shown on the quick-jump button — used only for the
                      // panel header display.
                      const displayName = thisFlyover.name;

                      // Close competing right-side panels so they don't stack
                      setShowOverview(false);
                      setShowSegmentTable(false);
                      setShowChart(false);
                      setShowDiffChart(false);
                      setShowTrafficPanel(false);

                      // Small delay lets the previous panel unmount cleanly
                      // before the new one mounts in the same slot.
                      setTimeout(() => {
                        setSelectedFlyoverForTraffic({ backendName, displayName });
                        setShowTrafficPanel(true);
                      }, 0);

                      // Highlight the matching quick-jump button
                      setActiveFlyoverId(flyover.id ?? index);

                      // Pan + zoom to the clicked marker
                      if (mapRef.current) {
                        mapRef.current.panTo(point.latlng);
                        setTimeout(() => {
                          mapRef.current?.setZoom(14);
                        }, 400);
                      }
                    });

                    flyoverMarkersRef.current.push(marker);
                    thisFlyover.markers.push(marker);
                  } catch (err) {
                    logError(
                      `[LULC] Error adding marker for ${point.name}:`,
                      err,
                    );
                  }
                });
              }

              // 🆕 Compute combined bounds for this flyover
              try {
                const group = L.featureGroup([
                  ...thisFlyover.layers,
                  ...thisFlyover.markers,
                ]);
                const b = group.getBounds();
                if (b && b.isValid()) {
                  thisFlyover.bounds = b;
                }
              } catch (err) {
                logError(
                  `[LULC] Could not compute bounds for ${thisFlyover.name}:`,
                  err,
                );
              }

              flyoverBoundsRef.current.push(thisFlyover);
            } catch (err) {
              logError(`[LULC] Error processing flyover ${index}:`, err);
            }
          });

          // 🆕 Mirror the populated ref into state so React re-renders the
          // flyover buttons by default (no user interaction required).
          setFlyoverEntries([...flyoverBoundsRef.current]);

          updateLayerVisibility();

          // 🆕 Force re-render of flyover buttons
          setActiveFlyoverId((prev) => prev);
        });
      } catch (err) {
        logError("[LULC] Error in addFlyoverLayers:", err);
      }
    },
    [flyovers, updateLayerVisibility],
  );

  /* ==========================================================================
   * UI HANDLERS
   * ========================================================================*/

  const handleLayerChange = useCallback((layer) => {
    log("Layer changed to:", layer);
    setSelectedLayer(layer);

    if (layer === "velocity") {
      setActiveLayers((prev) => {
        const next = prev.filter((id) => id !== "difference");
        if (!next.includes("movement")) {
          next.push("movement");
        }
        return next;
      });
      setShowDiffChart(false);
      setDiffPointData(null);
      setDiffDetailData(null);
    } else if (layer === "difference") {
      setActiveLayers((prev) => {
        const next = prev.filter((id) => id !== "movement");
        if (!next.includes("difference")) {
          next.push("difference");
        }
        return next;
      });
    } else if (layer === "none") {
      setActiveLayers((prev) =>
        prev.filter((id) => id !== "movement" && id !== "difference"),
      );
      setShowChart(false);
      setSelectedPointForChart(null);
      setSelectedDetailForChart(null);
      setShowDiffChart(false);
      setDiffPointData(null);
      setDiffDetailData(null);
    }
  }, []);

  const flyoverActivityNames = {
    F1: "1ROB(Chainage 5+362)-Button",
    F2: "2-Flyover-Button",
    F3: "3ROB(Chainage 0+930)-Button",
    F4: "4MNB-Button",
  };

  /* 🆕 Zoom + highlight a single flyover */
  const handleFlyoverButtonClick = useCallback(
    (flyoverEntry) => {
      const map = mapRef.current;
      if (!map || !flyoverEntry) return;

      // Toggle off if the same button is clicked again
      if (activeFlyoverId === flyoverEntry.id) {
        setActiveFlyoverId(null);
        flyoverBoundsRef.current.forEach((f) => {
          f.layers.forEach((layer) => {
            layer.setStyle({
              color: f.color,
              weight: 3,
              opacity: 0.8,
              fillColor: f.color,
              fillOpacity: 0.2,
            });
          });
        });
        return;
      }

      setActiveFlyoverId(flyoverEntry.id);
      // Capture flyover activity
      sendUserActivity(
        flyoverActivityNames[flyoverEntry.flyover] ||
        ` ${flyoverEntry.name}-Button`,
        "InfraRisk",
      );

      flyoverBoundsRef.current.forEach((f) => {
        const isActive = f.id === flyoverEntry.id;
        f.layers.forEach((layer) => {
          layer.setStyle({
            color: isActive ? "#facc15" : f.color,
            weight: isActive ? 6 : 3,
            opacity: isActive ? 1 : 0.8,
            fillColor: isActive ? "#facc15" : f.color,
            fillOpacity: isActive ? 0.35 : 0.2,
          });
        });
        if (isActive) {
          f.layers.forEach((layer) => {
            if (typeof layer.bringToFront === "function") layer.bringToFront();
          });
        }
      });

      // Zoom to the flyover bounds
      if (flyoverEntry.bounds && flyoverEntry.bounds.isValid()) {
        map.fitBounds(flyoverEntry.bounds, {
          padding: [60, 60],
          maxZoom: 18,
          animate: true,
        });
      }
    },
    [activeFlyoverId],
  );

  const handleLayerToggle = useCallback(
    async (layerId) => {
      if (layerId === "lulc") {
        setShowLULC((prev) => !prev);
        setShowSoil(false);
      } else if (layerId === "soil") {
        setShowSoil((prev) => {
          const next = !prev;
          if (next) {
            setShowChart(false);
            setSelectedPointForChart(null);
            setSelectedDetailForChart(null);
            setShowDiffChart(false);
            setDiffPointData(null);
            setDiffDetailData(null);
          }
          return next;
        });
        setShowLULC(false);
      } else if (layerId === "linear") {
        const isActive = activeLayers.includes("linear");
        if (isActive) {
          setActiveLayers((prev) => prev.filter((id) => id !== "linear"));

          if (
            liveSegmentLayerRef.current &&
            mapRef.current?.hasLayer(liveSegmentLayerRef.current)
          ) {
            mapRef.current.removeLayer(liveSegmentLayerRef.current);
            liveSegmentLayerRef.current = null;
          }
          if (
            selectedPolygonLayerRef.current &&
            mapRef.current?.hasLayer(selectedPolygonLayerRef.current)
          ) {
            mapRef.current.removeLayer(selectedPolygonLayerRef.current);
            selectedPolygonLayerRef.current = null;
          }

          // 🆕 Remove flyover pins when Assets is turned off
          removeAllFromMap(mapRef.current, flyoverLayersRef.current);
          removeAllFromMap(mapRef.current, flyoverMarkersRef.current);
        } else {
          setActiveLayers((prev) => [...prev, "linear"]);

          // 🆕 Add flyover pins when Assets is turned on — same look the
          // old Flyover layer used to give.
          if (mapRef.current && flyovers && flyovers.length > 0) {
            addFlyoverLayers(mapRef.current);
          }

          if (
            !liveSegments ||
            !liveSegments.features ||
            liveSegments.features.length === 0
          ) {
            setSegmentLoading(true);
            try {
              const data = await loadLiveSegments();
              const stats = await loadSegmentStats();

              if (data && data.features && data.features.length > 0) {
                const statsById = new Map(
                  (stats || []).map((s) => [Number(s.id), s]),
                );

                const extractedData = data.features.map((feature) => {
                  const id = parseInt(feature.properties?.objectid) || 0;
                  const stat = statsById.get(id);
                  return {
                    id,
                    name:
                      stat?.name || feature.properties?.name || "NH 152 Ambala",
                    avg_velocity:
                      stat?.avg_velocity ??
                      (feature.properties?.avg_velocity !== undefined
                        ? parseFloat(feature.properties.avg_velocity)
                        : null),
                    point_count: stat?.point_count ?? 0,
                  };
                });
                setSegmentData(extractedData);

                if (mapRef.current && isMapReadyRef.current) {
                  setTimeout(() => {
                    try {
                      addLiveSegmentLayer(mapRef.current);
                    } catch (err) {
                      logError("[LULC] Error adding segment layer:", err);
                    }
                  }, 100);
                }
              }
            } catch (err) {
              console.error("Error loading segments:", err);
            } finally {
              setSegmentLoading(false);
            }
          } else {
            if (mapRef.current && isMapReadyRef.current) {
              setTimeout(() => {
                try {
                  addLiveSegmentLayer(mapRef.current);
                } catch (err) {
                  logError("[LULC] Error adding segment layer:", err);
                }
              }, 100);
            }
          }
        }
      } else {
        setActiveLayers((prev) =>
          prev.includes(layerId)
            ? prev.filter((id) => id !== layerId)
            : [...prev, layerId],
        );
      }
    },
    [
      activeLayers,
      liveSegments,
      loadLiveSegments,
      loadSegmentStats,
      addLiveSegmentLayer,
      flyovers,
      addFlyoverLayers,
    ],
  );

  const handleBaseLayerChange = useCallback((layerType) => {
    setBaseLayer(layerType);

    if (!mapRef.current) {
      return;
    }

    try {
      if (
        streetLayerRef.current &&
        mapRef.current.hasLayer(streetLayerRef.current)
      ) {
        mapRef.current.removeLayer(streetLayerRef.current);
      }

      if (
        satelliteLayerRef.current &&
        mapRef.current.hasLayer(satelliteLayerRef.current)
      ) {
        mapRef.current.removeLayer(satelliteLayerRef.current);
      }

      if (
        esriSatelliteLayerRef.current &&
        mapRef.current.hasLayer(esriSatelliteLayerRef.current)
      ) {
        mapRef.current.removeLayer(esriSatelliteLayerRef.current);
      }

      if (layerType === "streets" && streetLayerRef.current) {
        mapRef.current.addLayer(streetLayerRef.current);
      } else if (layerType === "satellite" && satelliteLayerRef.current) {
        mapRef.current.addLayer(satelliteLayerRef.current);
      } else if (
        layerType === "esri_satellite" &&
        esriSatelliteLayerRef.current
      ) {
        mapRef.current.addLayer(esriSatelliteLayerRef.current);
      }

      if (
        leftLayerRef.current &&
        mapRef.current.hasLayer(leftLayerRef.current)
      ) {
        leftLayerRef.current.setZIndex(10);
      }

      if (
        rightLayerRef.current &&
        mapRef.current.hasLayer(rightLayerRef.current)
      ) {
        rightLayerRef.current.setZIndex(10);
      }

      if (
        sideBySideRef.current &&
        typeof sideBySideRef.current._updateClip === "function"
      ) {
        sideBySideRef.current._updateClip();
      }
    } catch (err) {
      logError("[LULC] Error switching base layer:", err);
    }
  }, []);

  const toggleFullscreen = useCallback(() => {
    try {
      const container = fullscreenContainerRef.current;
      if (!document.fullscreenElement) {
        container?.requestFullscreen?.();
      } else {
        document.exitFullscreen?.();
      }
    } catch (err) {
      logError("[LULC] Error toggling fullscreen:", err);
    }
  }, []);



  /* ==========================================================================
 * GPS / LOCATE-ME
 * ========================================================================*/
  const handleLocateMe = useCallback(() => {
    if (!mapRef.current) return;

    if (!("geolocation" in navigator)) {
      setGpsError("Geolocation is not supported by this browser.");
      setTimeout(() => setGpsError(null), 4000);
      return;
    }

    // Secure-context guard — geolocation silently misbehaves over plain HTTP
    if (!window.isSecureContext) {
      setGpsError(
        "Location requires HTTPS. Please open this site over https:// or localhost."
      );
      setTimeout(() => setGpsError(null), 5000);
      return;
    }

    setGpsLoading(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setGpsLoading(false);

        const { latitude, longitude, accuracy } = position.coords;
        const map = mapRef.current;
        if (!map) return;

        const latlng = [latitude, longitude]; // [lat, lng] — correct for Leaflet

        // Wipe any previous marker / halo
        if (userLocationMarkerRef.current) {
          map.removeLayer(userLocationMarkerRef.current);
          userLocationMarkerRef.current = null;
        }
        if (userAccuracyCircleRef.current) {
          map.removeLayer(userAccuracyCircleRef.current);
          userAccuracyCircleRef.current = null;
        }

        // Ensure a dedicated pane exists so GPS always draws on top
        if (!map.getPane("gpsPane")) {
          map.createPane("gpsPane");
          map.getPane("gpsPane").style.zIndex = 650; // above markers (600)
          map.getPane("gpsPane").style.pointerEvents = "none";
        }

        // --- Accuracy halo --------------------------------------------------
        // L.circle radius is METERS. Clamp so a bad IP fix doesn't paint a
        // country-sized disc.
        const haloRadius = Math.min(Math.max(accuracy || 30, 10), 2000);

        userAccuracyCircleRef.current = L.circle(latlng, {
          pane: "gpsPane",
          radius: haloRadius,
          color: "#2563eb",
          weight: 1,
          opacity: 0.7,
          fillColor: "#3b82f6",
          fillOpacity: 0.15,
          interactive: false,
        }).addTo(map);

        // --- Marker ---------------------------------------------------------
        // Inline styles on every element so this works even if the <style>
        // block below is missing/overridden.
        const userIcon = L.divIcon({
          className: "gps-user-marker-wrapper",
          html: `
          <div style="
            position: relative;
            width: 26px;
            height: 26px;
          ">
            <span style="
              position:absolute; inset:0;
              border-radius:50%;
              background: rgba(59,130,246,0.45);
              animation: gps-pulse 1.8s ease-out infinite;
            "></span>
            <span style="
              position:absolute;
              top:50%; left:50%;
              width:14px; height:14px;
              margin:-7px 0 0 -7px;
              border-radius:50%;
              background:#2563eb;
              border:2px solid #ffffff;
              box-shadow:0 0 6px rgba(0,0,0,0.45);
            "></span>
          </div>
        `,
          iconSize: [26, 26],
          iconAnchor: [13, 13],
          popupAnchor: [0, -13],
        });

        const marker = L.marker(latlng, {
          icon: userIcon,
          pane: "gpsPane",
          zIndexOffset: 2000,
          keyboard: false,
        }).addTo(map);

        marker.bindPopup(
          `<div style="font-size:12px; font-family:Arial,sans-serif; padding:2px 4px;">
           <strong>You are here</strong><br/>
           Lat: ${latitude.toFixed(5)}<br/>
           Lng: ${longitude.toFixed(5)}<br/>
           Accuracy: ±${Math.round(accuracy)} m
         </div>`
        );

        userLocationMarkerRef.current = marker;

        // --- Camera ---------------------------------------------------------
        // If accuracy is bad, zoom out enough to fit the halo instead of
        // slamming to zoom 16 on a meaningless point.
        const targetZoom =
          accuracy && accuracy > 500
            ? Math.min(map.getZoom(), 13)
            : Math.max(map.getZoom(), 16);

        map.flyTo(latlng, targetZoom, { animate: true, duration: 1.2 });

        // Open popup a moment after the fly settles
        setTimeout(() => {
          if (userLocationMarkerRef.current) {
            userLocationMarkerRef.current.openPopup();
          }
        }, 1300);

        sendUserActivity("Clicked GPS-Locate-Button", "InfraRisk");
      },
      (err) => {
        setGpsLoading(false);

        let msg = "Unable to get your location.";
        switch (err.code) {
          case err.PERMISSION_DENIED:
            msg = "Location permission denied.";
            break;
          case err.POSITION_UNAVAILABLE:
            msg = "Location information is unavailable.";
            break;
          case err.TIMEOUT:
            msg = "Location request timed out.";
            break;
          default:
            msg = err.message || msg;
        }
        setGpsError(msg);
        setTimeout(() => setGpsError(null), 4000);
      },
      {
        // 🔑 The three biggest fixes for "wrong location":
        enableHighAccuracy: false, // let the browser use Wi-Fi/IP when GPS is absent
        timeout: 15000,            // give it more time than 10 s
        maximumAge: 30000,         // accept a fix up to 30 s old
      }
    );
  }, []);


  /* ==========================================================================
   * EFFECTS
   * ========================================================================*/

  useEffect(() => {
    if (
      availableDates &&
      availableDates.length > 0 &&
      !diffStartDate &&
      !diffEndDate
    ) {
      setDiffStartDate(availableDates[0]);
      setDiffEndDate(availableDates[availableDates.length - 1]);
    }
  }, [availableDates]);

  useEffect(() => {
    let cancelled = false;

    const fetchSoilData = async () => {
      try {
        setSoilLoading(true);
        setSoilError(null);

        const response = await fetch(`${BASE}data/Soil.geojson`);
        if (!response.ok) {
          throw new Error(`Failed to load soil data: ${response.status}`);
        }

        const data = await response.json();
        if (cancelled) return;

        soilDataRef.current = data;
        setSoilData(data);

        setTaxoValues(
          Array.from(
            new Set(
              (data.features || [])
                .map((feature) => feature.properties?.S_TAXO)
                .filter(Boolean),
            ),
          ).sort(),
        );
      } catch (err) {
        if (!cancelled) {
          console.error("[LULC] Error loading soil data:", err);
          setSoilError(err.message || "Failed to load soil data");
        }
      } finally {
        if (!cancelled) setSoilLoading(false);
      }
    };

    fetchSoilData();

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (movementPoints && movementPoints.length > 0) {
      log(`Movement Points loaded: ${movementPoints.length} points`);
      log("Sample point:", movementPoints[0]);
    }

    if (movementError) {
      logError("Movement Points Error:", movementError);
    }

    if (availableDates && availableDates.length > 0) {
      log("Available dates:", availableDates);
    }
  }, [movementPoints, movementError, availableDates]);

  useEffect(() => {
    if (!mapRef.current || !isActive) {
      return;
    }

    if (!movementPoints || movementPoints.length === 0) {
      return;
    }

    const timeoutId = setTimeout(() => {
      try {
        addMovementPointsToMap(mapRef.current, movementPoints);
      } catch (err) {
        logError("[LULC] Error adding movement points:", err);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [movementPoints, isActive, addMovementPointsToMap]);

  useEffect(() => {
    if (!mapRef.current) return;
    updateMovementVisibility();
  }, [selectedLayer, updateMovementVisibility]);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 1024);
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (loading || error) {
      return;
    }

    const zoomEl = zoomControlContainerRef.current;
    const wrapperEl = layerControlWrapperRef.current;

    if (!zoomEl || !wrapperEl) {
      return;
    }

    if (wrapperEl.firstChild !== zoomEl) {
      wrapperEl.insertBefore(zoomEl, wrapperEl.firstChild);
    }
  }, [loading, error]);

  /* 🆕 CHANGED: added `.leaflet-bar a` override so the native Leaflet
     zoom control (+/-) matches the reduced size of the FullscreenButton
     and Layers button (28px desktop / 24px mobile) in the same stack.
     Leaflet's own CSS ships a fixed size for these anchors that can't be
     changed via className since they're rendered by Leaflet itself. */
  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = `
    /* 🆕 GPS marker pulse */
    @keyframes gps-pulse {
      0%   { transform: scale(0.6); opacity: 0.9; }
      70%  { transform: scale(2.2); opacity: 0;   }
      100% { transform: scale(2.2); opacity: 0;   }
    }
    .gps-user-marker-wrapper {
      background: transparent !important;
      border: none !important;
    }

    /* existing overrides — unchanged */
    .leaflet-interactive:focus,
    .leaflet-interactive:focus-visible {
      outline: none !important;
    }
    path.leaflet-interactive:focus {
      outline: none !important;
    }
    .leaflet-bar a {
      width: 22px !important;
      height: 22px !important;
      line-height: 22px !important;
      font-size: 14px !important;
    }
    @media (max-width: 480px) {
      .leaflet-bar a {
        width: 18px !important;
        height: 18px !important;
        line-height: 18px !important;
        font-size: 12px !important;
      }
    }
  `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
      setTimeout(() => {
        try {
          if (
            mapRef.current &&
            mapContainerRef.current &&
            document.contains(mapContainerRef.current)
          ) {
            mapRef.current.invalidateSize();
          }
        } catch (err) {
          logError("[LULC] Error during fullscreen change:", err);
        }
      }, 200);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () =>
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  useEffect(() => {
    if (mapRef.current) {
      updateLayerVisibility();
    }
  }, [activeLayers, updateLayerVisibility]);

  useEffect(() => {
    if (!leftLayerRef.current || !rightLayerRef.current) {
      return;
    }

    leftLayerRef.current.setUrl(
      TILE_LAYER_URL.replace("{year}", String(yearLeft)),
    );
    rightLayerRef.current.setUrl(
      TILE_LAYER_URL.replace("{year}", String(yearRight)),
    );
  }, [yearLeft, yearRight]);

  useEffect(() => {
    if (!mapRef.current) {
      return;
    }

    if (showLULC && !lulcCreatedRef.current) {
      ensureLULCLayersExist();

      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          if (!isMountedRef.current) {
            return;
          }

          leftLayerRef.current?.setOpacity(1);
          rightLayerRef.current?.setOpacity(1);

          const controlEl = sideBySideRef.current?._container;

          if (controlEl) {
            controlEl.style.opacity = "1";
            controlEl.style.pointerEvents = "auto";
          }

          if (tagRef.current) {
            tagRef.current.style.opacity = "1";
          }

          if (dividerLineRef.current) {
            dividerLineRef.current.style.opacity = "1";
          }
        });
      });

      return;
    }

    if (!lulcCreatedRef.current) {
      return;
    }

    const opacity = showLULC ? 1 : 0;

    leftLayerRef.current?.setOpacity(opacity);
    rightLayerRef.current?.setOpacity(opacity);

    const controlEl = sideBySideRef.current?._container;

    if (controlEl) {
      controlEl.style.opacity = String(opacity);
      controlEl.style.pointerEvents = showLULC ? "auto" : "none";
    }

    if (tagRef.current) {
      tagRef.current.style.opacity = String(opacity);
    }

    if (dividerLineRef.current) {
      dividerLineRef.current.style.opacity = String(opacity);
    }
  }, [showLULC, ensureLULCLayersExist]);

  /* 🆕 Auto-activate the first flyover button once the entries exist, so the
     map zooms to it by default without any user interaction. A small delay
     lets the map finish its initial layout before we call fitBounds. */
  const hasAutoClickedFirstFlyoverRef = useRef(false);

  useEffect(() => {
    if (hasAutoClickedFirstFlyoverRef.current) return;
    if (!flyoverEntries.length) return;
    if (!activeLayers.includes("linear")) return;

    const first = flyoverEntries[0];
    if (!first || !first.bounds || !first.bounds.isValid()) return;

    hasAutoClickedFirstFlyoverRef.current = true;

    // 🆕 Delay so the map settles before zooming
    const delayMs = 600;

    const timeoutId = setTimeout(() => {
      if (!mapRef.current) return;
      handleFlyoverButtonClick(first);
    }, delayMs);

    return () => clearTimeout(timeoutId);
  }, [flyoverEntries, activeLayers, handleFlyoverButtonClick]);

  /* ==========================================================================
   * SOIL LAYER
   * ========================================================================*/

  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;

    const map = mapRef.current;

    if (!showSoil) {
      if (soilLayerRef.current && map.hasLayer(soilLayerRef.current)) {
        map.removeLayer(soilLayerRef.current);
      }
      soilLayerRef.current = null;
      hasFitSoilBoundsRef.current = false;
      return;
    }

    if (!soilData) return;

    if (soilLayerRef.current && map.hasLayer(soilLayerRef.current)) {
      map.removeLayer(soilLayerRef.current);
    }

    soilLayerRef.current = L.geoJSON(soilData, {
      pane: "soilPane",
      style: soilStyle,
      onEachFeature: onEachSoilFeature,
    }).addTo(map);

    if (!hasFitSoilBoundsRef.current) {
      try {
        const bounds = soilLayerRef.current.getBounds();
        if (bounds.isValid()) {
          map.setView(bounds.getCenter(), DEFAULT_ZOOM, { animate: false });
          hasFitSoilBoundsRef.current = true;
        }
      } catch (err) {
        console.warn("[LULC] Could not set soil view:", err);
      }
    }

    requestAnimationFrame(() => {
      if (mapRef.current && mapContainerRef.current) {
        mapRef.current.invalidateSize();
      }
    });

    return () => {
      if (soilLayerRef.current && map.hasLayer(soilLayerRef.current)) {
        map.removeLayer(soilLayerRef.current);
      }
    };
  }, [showSoil, soilData]);

  /* ==========================================================================
   * INITIALIZE MAP
   * ========================================================================*/

  useEffect(() => {
    isMountedRef.current = true;

    if (mapRef.current || !mapContainerRef.current) {
      return;
    }

    try {
      const map = L.map(mapContainerRef.current, {
        center: mapCenter,
        zoom: DEFAULT_ZOOM,
        minZoom: MIN_ZOOM,
        maxZoom: MAX_ZOOM,
        zoomControl: false,
        attributionControl: false,
        fadeAnimation: true,
      });

      const zoomControl = L.control
        .zoom({
          position: "topleft",
        })
        .addTo(map);

      const zoomControlContainer = zoomControl.getContainer();

      if (zoomControlContainer) {
        zoomControlContainer.style.setProperty(
          "position",
          "static",
          "important",
        );
        zoomControlContainer.style.setProperty("margin", "0", "important");
        zoomControlContainer.style.setProperty("float", "none", "important");
        zoomControlContainer.style.setProperty("clear", "none", "important");
        zoomControlContainerRef.current = zoomControlContainer;
      }

      const streetLayer = L.tileLayer(
        "https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}",
        {
          subdomains: ["mt0", "mt1", "mt2", "mt3"],
          maxZoom: 25,
          attribution: "",
          zIndex: 1,
        },
      );

      const satelliteLayer = L.tileLayer(
        "https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",
        {
          subdomains: ["mt0", "mt1", "mt2", "mt3"],
          maxZoom: 25,
          attribution: "",
          zIndex: 1,
        },
      );

      const esriSatelliteLayer = L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          maxZoom: 18,
          attribution: "",
          zIndex: 1,
        },
      );

      streetLayerRef.current = streetLayer;
      satelliteLayerRef.current = satelliteLayer;
      esriSatelliteLayerRef.current = esriSatelliteLayer;

      streetLayer.addTo(map);

      L.control
        .attribution({
          position: "bottomright",
          prefix: false,
        })
        .addTo(map);

      mapRef.current = map;
      isMapReadyRef.current = true;

      map.createPane("soilPane");
      map.getPane("soilPane").style.zIndex = 300;
      map.getPane("soilPane").style.pointerEvents = "auto";

      map.createPane("movementPane");
      map.getPane("movementPane").style.zIndex = 550;
      map.getPane("movementPane").style.pointerEvents = "auto";

      map.on("zoomend", updateCircleWeights);

      const popupPane = map.getPane("popupPane");
      const mapPaneEl = map.getPane("mapPane");

      if (popupPane && mapPaneEl && popupPane.parentNode === mapPaneEl) {
        map.getContainer().appendChild(popupPane);
        popupPane.style.zIndex = "1400";
        popupPane.style.pointerEvents = "none";

        const syncPopupPanePosition = () => {
          popupPane.style.transform = mapPaneEl.style.transform;
        };

        map.on("move zoom viewreset", syncPopupPanePosition);
        syncPopupPanePosition();
      }

      if (typeof ResizeObserver !== "undefined") {
        resizeObserverRef.current = new ResizeObserver(() => {
          try {
            if (
              mapRef.current &&
              mapContainerRef.current &&
              document.contains(mapContainerRef.current)
            ) {
              mapRef.current.invalidateSize();
            }
          } catch (err) {
            logError("[LULC] Error in resize observer:", err);
          }
        });
        resizeObserverRef.current.observe(mapContainerRef.current);
      }

      if (flyovers && flyovers.length > 0) {
        setTimeout(() => {
          try {
            addFlyoverLayers(map);
          } catch (err) {
            logError("[LULC] Error adding flyover layers:", err);
          }
        }, 300);
      }

      setTimeout(() => {
        if (isMountedRef.current) {
          setLoading(false);
        }
      }, 200);

      return () => {
        isMountedRef.current = false;

        if (debounceRef.current) {
          clearTimeout(debounceRef.current);
        }

        if (dividerReadyTimeoutRef.current) {
          clearTimeout(dividerReadyTimeoutRef.current);
        }

        if (rafIdRef.current) {
          cancelAnimationFrame(rafIdRef.current);
        }

        resizeObserverRef.current?.disconnect();

        sideBySideRef.current = null;

        if (
          soilLayerRef.current &&
          mapRef.current?.hasLayer(soilLayerRef.current)
        ) {
          mapRef.current.removeLayer(soilLayerRef.current);
        }
        soilLayerRef.current = null;
        soilDataRef.current = null;
        hasFitSoilBoundsRef.current = false;

        if (
          liveSegmentLayerRef.current &&
          mapRef.current?.hasLayer(liveSegmentLayerRef.current)
        ) {
          mapRef.current.removeLayer(liveSegmentLayerRef.current);
          liveSegmentLayerRef.current = null;
        }

        if (
          selectedPolygonLayerRef.current &&
          mapRef.current?.hasLayer(selectedPolygonLayerRef.current)
        ) {
          mapRef.current.removeLayer(selectedPolygonLayerRef.current);
          selectedPolygonLayerRef.current = null;
        }

        // 🆕 Clear diff circles
        removeAllFromMap(mapRef.current, diffMarkersRef.current);
        diffMarkersRef.current = [];

        leftLayerRef.current = null;
        rightLayerRef.current = null;
        lulcCreatedRef.current = false;

        selectedMovementMarkerRef.current = null;

        if (mapRef.current) {
          try {
            mapRef.current.off("zoomend", updateCircleWeights);
            mapRef.current.remove();
            mapRef.current = null;
          } catch (err) {
            logError("[LULC] Error removing map:", err);
          }
        }

        isMapReadyRef.current = false;
      };
    } catch (err) {
      logError("[LULC] Error initializing map:", err);
      setError("Failed to initialize map. Please try again.");
      setLoading(false);
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!mapRef.current || !isActive) {
      return;
    }

    if (!flyovers || flyovers.length === 0) {
      return;
    }

    const timeoutId = setTimeout(() => {
      try {
        addFlyoverLayers(mapRef.current);
      } catch (err) {
        logError("[LULC] Error adding flyover layers:", err);
      }
    }, 500);

    return () => clearTimeout(timeoutId);
  }, [flyovers, isActive, addFlyoverLayers]);

  useEffect(() => {
    if (isActive) {
      return;
    }
    teardownLULCLayers();
  }, [isActive, teardownLULCLayers]);

  useEffect(() => {
    if (!isActive || !mapRef.current || !mapContainerRef.current) {
      return;
    }

    const raf = requestAnimationFrame(() => {
      try {
        if (
          mapRef.current &&
          mapContainerRef.current &&
          document.contains(mapContainerRef.current)
        ) {
          mapRef.current.invalidateSize();
        }
      } catch (err) {
        logError("[LULC] Error invalidating size on active:", err);
      }
    });

    return () => cancelAnimationFrame(raf);
  }, [isActive]);

  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;
    if (!showSegmentsUI || !liveSegments) return;

    const timeoutId = setTimeout(() => {
      try {
        addLiveSegmentLayer(mapRef.current);
      } catch (err) {
        logError("[LULC] Error adding segment layer:", err);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [showSegmentsUI, liveSegments, addLiveSegmentLayer]);

  useEffect(() => {
    if (!mapRef.current || !isMapReadyRef.current) return;

    if (!activeLayers.includes("linear") && !showSegmentsUI) {
      if (
        liveSegmentLayerRef.current &&
        mapRef.current.hasLayer(liveSegmentLayerRef.current)
      ) {
        mapRef.current.removeLayer(liveSegmentLayerRef.current);
        liveSegmentLayerRef.current = null;
      }
      return;
    }

    if (
      liveSegments &&
      liveSegments.features &&
      liveSegments.features.length > 0
    ) {
      if (
        liveSegmentLayerRef.current &&
        mapRef.current.hasLayer(liveSegmentLayerRef.current)
      ) {
        return;
      }

      const timeoutId = setTimeout(() => {
        try {
          addLiveSegmentLayer(mapRef.current);
        } catch (err) {
          logError("[LULC] Error adding segment layer:", err);
        }
      }, 200);
      return () => clearTimeout(timeoutId);
    } else if (showSegmentsUI && !liveSegments) {
      loadLiveSegments().catch((err) => {
        logError("[LULC] Error loading live segments:", err);
      });
    }
  }, [
    showSegmentsUI,
    liveSegments,
    loadLiveSegments,
    addLiveSegmentLayer,
    activeLayers,
  ]);

  /* ==========================================================================
   * RENDER
   * ========================================================================*/

  return (
    <div
      className={`flex flex-col h-full w-full ${className}`}
      ref={fullscreenContainerRef}
      style={{
        background: "#ffffff",
        paddingTop: isFullscreen ? "10px" : "0px",
      }}
    >
      {/* TOP CONTROL BAR */}
      <div
        className="flex flex-wrap items-center justify-between gap-3 mb-2 px-3 py-2 rounded-lg relative z-[2000] max-[640px]:flex-col max-[640px]:items-stretch max-[640px]:gap-2 max-[640px]:px-2 max-[640px]:py-1.5"
        style={{
          background:
            "linear-gradient(135deg, #e0e7ff 0%, #dbeafe 50%, #ede9fe 100%)",
          borderRadius: "10px",
          boxShadow: "0 2px 10px rgba(99, 102, 241, 0.1)",
          border: "1px solid rgba(99, 102, 241, 0.1)",
        }}
      >
        <div className="flex items-center gap-3 flex-wrap max-[640px]:gap-2 max-[640px]:w-full max-[640px]:justify-between">
          <div className="flex items-center gap-3 flex-wrap max-[640px]:gap-2">
            <LayerSelector
              selectedLayer={selectedLayer}
              onLayerChange={handleLayerChange}
            />
          </div>

          <div className="flex items-center gap-3 flex-wrap max-[640px]:gap-2">
            {showDifferenceUI && availableDates.length > 0 && (
              <DateRangeSelector
                availableDates={availableDates}
                startDate={diffStartDate}
                endDate={diffEndDate}
                onStartDateChange={setDiffStartDate}
                onEndDateChange={setDiffEndDate}
              />
            )}

            <button
              onClick={() => {
                const willOpen = !showSegmentTable;

                setShowSegmentTable(willOpen);
                setShowOverview(false);

                if (willOpen) {
                  sendUserActivity("Liner-Button", "InfraRisk");
                }
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-all duration-200 border ${showSegmentTable
                ? "bg-purple-100 text-purple-800 border-purple-300 shadow-sm"
                : "bg-white/80 text-gray-700 border-gray-300 hover:bg-gray-100"
                }`}
            >
              <Table size={14} />
              Linear
            </button>

            <button
              onClick={() => {
                sendUserActivity(" Overview-Button", "InfraRisk");

                setShowOverview((prev) => !prev);
                setShowSegmentTable(false);
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-all duration-200 border ${showOverview
                ? "bg-blue-100 text-blue-800 border-blue-300 shadow-sm"
                : "bg-white/80 text-gray-700 border-gray-300 hover:bg-gray-100"
                }`}
            >
              Overview
            </button>
          </div>
        </div>

        {showLULC && (
          <div className="flex items-center gap-4 max-[640px]:w-full max-[640px]:flex-wrap max-[640px]:gap-2">
            <span className="font-bold text-black text-md tracking-wide max-[480px]:text-xs max-[480px]:w-full">
              Land Cover Comparison
            </span>
            <YearSelect
              label="Left"
              value={yearLeft}
              onChange={setYearLeft}
              disabledYears={[yearRight]}
            />
            <YearSelect
              label="Right"
              value={yearRight}
              onChange={setYearRight}
              disabledYears={[yearLeft]}
            />
          </div>
        )}
      </div>

      {/* MAP CONTAINER */}
      <div
        className="flex-1 min-h-0 relative rounded-lg overflow-hidden border border-gray-200"
        style={{
          height: isMobile ? "450px" : "100%",
          minHeight: isMobile ? "400px" : "auto",
        }}
      >
        <div ref={mapContainerRef} className="absolute inset-0" />

        {/* LEGENDS */}
        {!loading && !error && !soilError && (
          <>
            {!showSoil && showLULC && <LULCLegend />}
            {!showSoil && showVelocityUI && <VelocityLegend />}
            {!showSoil && showDifferenceUI && velocityDiffRange && (
              <VelocityDiffLegend range={velocityDiffRange} />
            )}
            {showSoil && !soilLoading && <SoilLegend taxoValues={taxoValues} />}
            {showSegmentTable && <RiskLegend />}
          </>
        )}

        {/* LAYER BUTTON + PANEL (Zoom control is inserted as firstChild via
            the layerControlWrapperRef effect, so the stacking order ends
            up: Zoom In/Out → Fullscreen → Layers, per TL request.) */}
        {!loading && !error && (
          <div
            ref={layerControlWrapperRef}
            className="absolute top-2 left-2 z-[1500] flex flex-col items-start gap-1 max-[480px]:gap-0.5"
          >
            <FullscreenButton
              isFullscreen={isFullscreen}
              onToggle={toggleFullscreen}
            />

            {/* 🆕 GPS Locate-Me button */}
            <button
              onClick={handleLocateMe}
              title="Show my location"
              disabled={gpsLoading}
              className={`
    flex items-center justify-center
    w-[22px] h-[22px]
    max-[480px]:w-[18px] max-[480px]:h-[18px]
    bg-white
    rounded-[4px]
    border-2
    transition-all duration-200
    hover:bg-gray-50
    border-gray-400 text-gray-700 hover:border-gray-500
    focus:outline-none focus:ring-0
    leaflet-bar
    ${gpsLoading ? "opacity-70 cursor-wait" : ""}
  `}
              style={{ boxShadow: "0 1px 5px rgba(0,0,0,0.1)" }}
              aria-label="Show my location"
            >
              {gpsLoading ? (
                <Loader2
                  size={13}
                  className="animate-spin max-[480px]:w-2.5 max-[480px]:h-2.5"
                />
              ) : (
                <Navigation
                  size={13}
                  className="max-[480px]:w-2.5 max-[480px]:h-2.5"
                />
              )}
            </button>


            {/* Layer button + panel */}
            <div className="relative">
              <button
                onClick={() => setIsLayerPanelOpen(!isLayerPanelOpen)}
                title="Layer Control"
                className={`
    flex items-center justify-center
    w-[22px] h-[22px]
    max-[480px]:w-[18px] max-[480px]:h-[18px]
    bg-white
    rounded-[4px]
    border-2
    transition-all duration-200
    hover:bg-gray-50
    ${isLayerPanelOpen
                    ? "border-blue-500 bg-blue-50 text-blue-600"
                    : "border-gray-400 text-gray-700 hover:border-gray-500"
                  }
    focus:outline-none
    focus:ring-0
    leaflet-bar
  `}
                style={{
                  boxShadow: "0 1px 5px rgba(0,0,0,0.1)",
                }}
                aria-label="Toggle layer control"
              >
                <Layers
                  size={13}
                  className="max-[480px]:w-2.5 max-[480px]:h-2.5"
                />
              </button>

              {isLayerPanelOpen && (
                <div
                  className="
            absolute top-0 left-full ml-2
            bg-white
            rounded-[4px]
            border-2 border-gray-300
            p-3
            min-w-[140px]
            max-w-[200px]
            max-[480px]:min-w-[140px]
            max-[480px]:max-w-[190px]
            max-[480px]:p-2
            shadow-lg
          "
                  style={{
                    boxShadow: "0 2px 10px rgba(0,0,0,0.15)",
                  }}
                >
                  <div className="flex items-center justify-between mb-1 pb-1 border-b border-gray-200">
                    <h3 className="text-xs font-semibold text-gray-700 max-[500px]:text-[10px] whitespace-nowrap">
                      Add-on Layer
                    </h3>
                    <button
                      onClick={() => setIsLayerPanelOpen(false)}
                      className="text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full p-0.5 transition-all duration-200"
                    >
                      <X
                        size={16}
                        strokeWidth={3}
                        className="max-[480px]:w-3.5 max-[480px]:h-3.5"
                      />
                    </button>
                  </div>

                  <div>
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5 max-[480px]:text-[9px]">
                      Overlays
                    </p>
                    <div className="flex flex-col gap-1.5">
                      {availableLayers.map((layer) => (
                        <label
                          key={layer.id}
                          className="flex items-center gap-2 text-xs text-gray-700 cursor-pointer hover:text-blue-600 transition-colors max-[480px]:text-[10px] max-[480px]:gap-1.5"
                        >
                          <input
                            type="checkbox"
                            checked={
                              layer.id === "lulc"
                                ? showLULC
                                : layer.id === "soil"
                                  ? showSoil
                                  : layer.id === "linear"
                                    ? activeLayers.includes("linear")
                                    : activeLayers.includes(layer.id)
                            }
                            onChange={() => handleLayerToggle(layer.id)}
                            className="w-3.5 h-3.5 rounded border-gray-300 text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer max-[480px]:w-3 max-[480px]:h-3"
                          />
                          <span className="whitespace-nowrap">
                            {layer.name}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="mt-2 pt-1 border-t border-gray-100">
                    <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider mb-1.5 max-[480px]:text-[9px]">
                      Base Map
                    </p>
                    <div className="flex flex-col gap-1.5">
                      <label className="flex items-center gap-2 text-xs text-gray-700 cursor-pointer hover:text-blue-600 transition-colors max-[480px]:text-[10px] max-[480px]:gap-1.5">
                        <input
                          type="radio"
                          name="baseLayer"
                          checked={baseLayer === "streets"}
                          onChange={() => handleBaseLayerChange("streets")}
                          className="w-3.5 h-3.5 text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer max-[480px]:w-3 max-[480px]:h-3"
                        />
                        <span className="whitespace-nowrap">Streets</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs text-gray-700 cursor-pointer hover:text-blue-600 transition-colors max-[480px]:text-[10px] max-[480px]:gap-1.5">
                        <input
                          type="radio"
                          name="baseLayer"
                          checked={baseLayer === "satellite"}
                          onChange={() => handleBaseLayerChange("satellite")}
                          className="w-3.5 h-3.5 text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer max-[480px]:w-3 max-[480px]:h-3"
                        />
                        <span className="whitespace-nowrap">
                          Google Satellite
                        </span>
                      </label>
                      <label className="flex items-center gap-2 text-xs text-gray-700 cursor-pointer hover:text-blue-600 transition-colors max-[480px]:text-[10px] max-[480px]:gap-1.5">
                        <input
                          type="radio"
                          name="baseLayer"
                          checked={baseLayer === "esri_satellite"}
                          onChange={() =>
                            handleBaseLayerChange("esri_satellite")
                          }
                          className="w-3.5 h-3.5 text-blue-600 focus:ring-0 focus:ring-offset-0 cursor-pointer max-[480px]:w-3 max-[480px]:h-3"
                        />
                        <span className="whitespace-nowrap">Satellite</span>
                      </label>
                    </div>
                  </div>
                </div>
              )}
            </div>


          </div>
        )}

        {/* Flyover quick-jump buttons — top row on desktop, 2-column grid
            on mobile (per TL: keep them at the top like desktop, but wrap
            into 2 buttons per row below 480px instead of a horizontal
            scroll or single vertical column). */}
        {!loading &&
          !error &&
          activeLayers.includes("linear") &&
          flyoverEntries.length > 0 && (
            <div
              ref={flyoverButtonsContainerRef}
              className="absolute top-2 left-10 right-14 z-[1500] flex flex-row items-center gap-1.5 overflow-x-auto max-[480px]:grid max-[480px]:grid-cols-2 max-[480px]:gap-1 max-[480px]:overflow-visible"
              style={{ pointerEvents: "auto" }}
            >
              {flyoverEntries.map((f) => {
                const isActive = activeFlyoverId === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => handleFlyoverButtonClick(f)}
                    title={f.name}
                    className={`
              flex items-center gap-2
              h-[28px]
              max-[480px]:h-[22px]
              w-auto
              min-w-[80px]
              max-w-[160px]
              max-[480px]:w-full
              max-[480px]:min-w-0
              max-[480px]:max-w-none
              px-2
              max-[480px]:px-1
              rounded-[4px]
              border-2
              flex-shrink-0
              transition-all duration-200
              focus:outline-none
              focus:ring-0
              leaflet-bar
              ${isActive
                        ? "border-yellow-500 bg-yellow-50 text-yellow-700"
                        : "border-gray-400 bg-white text-gray-700 hover:border-gray-500 hover:bg-gray-50"
                      }
            `}
                    style={{ boxShadow: "0 1px 5px rgba(0,0,0,0.1)" }}
                    aria-label={`Zoom to ${f.name}`}
                  >
                    <span
                      className="w-2.5 h-2.5 max-[480px]:w-2 max-[480px]:h-2 rounded-full flex-shrink-0"
                      style={{ backgroundColor: f.color }}
                    />
                    <span className="text-[10px] max-[480px]:text-[9px] font-semibold truncate text-left min-w-0">
                      {f.name}
                    </span>
                  </button>
                );
              })}
            </div>
          )}

        {/* SEGMENT / LINEAR TABLE OVERLAY */}
        {showSegmentsUI && showSegmentTable && (
          <div
            className=" absolute top-2 right-3 z-[1500]
      max-w-[260px] w-full max-h-[320px]
      bg-white/95 backdrop-blur-sm rounded-lg shadow-lg border border-gray-200
      overflow-hidden

      max-[480px]:top-auto
      max-[480px]:bottom-14
      max-[480px]:right-2
      max-[480px]:left-auto
      max-[480px]:w-auto
      max-[480px]:max-w-[220px]
      max-[480px]:max-h-[220px]"
          >
            <div className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b border-gray-200">
              <span className="text-xs font-semibold text-gray-700 flex items-center gap-2">
                <Table size={14} />
                Linear (
                {/* {segmentData.filter((d) => d.avg_velocity !== null).length}{" "} */}
                active observations)
              </span>
              <button
                onClick={() => setShowSegmentTable(false)}
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <X size={14} />
              </button>
            </div>
            <SegmentTable
              data={segmentData}
              onRowClick={handleSegmentRowClick}
              selectedId={selectedSegmentId}
              loading={segmentLoading}
            />
          </div>
        )}

        {/* RiskOverviewPanel: bottom-right on mobile (matching the corner
            LULC/Soil/Risk legends use), top-right on desktop. If it ever
            needs to coexist on mobile with those legends, consider adding
            a conditional bottom offset the same way the flyover row's
            lift was explored earlier. */}
        {showOverview && (
          <RiskOverviewPanel onClose={() => setShowOverview(false)} />
        )}



        {/* Traffic Analysis Panel — right-side overlay */}

        {showTrafficPanel && (
          <div
            className="absolute top-2 right-2 z-[1500]"
            style={{
              width: isMobile ? "min(92vw, 380px)" : "400px",
              height: isMobile ? "auto" : "calc(100% - 1rem)",
              maxHeight: isMobile ? "500px" : "calc(100% - 1rem)",
              display: "flex",
              overflow: "visible",
              overscrollBehavior: "contain",
              pointerEvents: "auto",
            }}
          >
            {/* <TrafficAnalysisPanel
              selectedFlyoverForTraffic={selectedFlyoverForTraffic}
              onClose={() => {
                setShowTrafficPanel(false);
                setSelectedFlyoverForTraffic(null);
              }}
              isMobile={isMobile}
            /> */}

            <TrafficAnalysisPanel
              selectedFlyoverForTraffic={selectedFlyoverForTraffic?.backendName || null}
              displayName={selectedFlyoverForTraffic?.displayName || null}
              onClose={() => {
                setShowTrafficPanel(false);
                setSelectedFlyoverForTraffic(null);
              }}
              isMobile={isMobile}
            />
          </div>
        )}

        {/* Risk Overview Panel — only when traffic panel is closed */}
        {showOverview && !showTrafficPanel && (
          <RiskOverviewPanel onClose={() => setShowOverview(false)} />
        )}









        {/* LULC DIVIDER TAG */}
        <div
          ref={tagRef}
          className="absolute bottom-4 pointer-events-none max-[480px]:bottom-2"
          style={{
            left: "0px",
            transform: "translateX(-50%)",
            opacity: 0,
            transition: `opacity ${LULC_FADE_MS}ms ease`,
            zIndex: 400,
          }}
        >
          <div className="flex items-center gap-2 bg-gray-900/80 backdrop-blur-sm text-white text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg max-[480px]:text-[10px] max-[480px]:px-2 max-[480px]:py-1">
            <span>{yearLeft}</span>
            <span className="text-gray-400">|</span>
            <span>{yearRight}</span>
          </div>
        </div>

        {/* LULC DIVIDER LINE */}
        <div
          ref={dividerLineRef}
          className="absolute top-0 bottom-0 pointer-events-none"
          style={{
            left: "0px",
            width: "2px",
            background: "rgba(59, 130, 246, 0.5)",
            transform: "translateX(-50%)",
            boxShadow: "0 0 10px rgba(59, 130, 246, 0.3)",
            opacity: 0,
            transition: `opacity ${LULC_FADE_MS}ms ease`,
            zIndex: 399,
          }}
        />

        {/* LOADING */}
        {(loading ||
          flyoversLoading ||
          movementLoading ||
          (showSoil && soilLoading) ||
          (showSegmentsUI && segmentLoading) ||
          (showDifferenceUI && velocityDiffLoading)) && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/70 backdrop-blur-sm z-[500]">
              <div className="flex flex-col items-center gap-2 bg-white px-5 py-4 rounded-xl shadow-lg border border-gray-200 max-[480px]:px-3 max-[480px]:py-3">
                <div className="w-8 h-8 border-4 border-gray-300 border-t-blue-600 rounded-full animate-spin max-[480px]:w-6 max-[480px]:h-6" />
                <p className="text-xs text-gray-500 max-[480px]:text-[10px] text-center">
                  {loading
                    ? "Initializing map..."
                    : showSoil && soilLoading
                      ? "Loading soil data..."
                      : movementLoading
                        ? "Loading movement points..."
                        : showDifferenceUI && velocityDiffLoading
                          ? "Loading velocity difference..."
                          : showSegmentsUI && segmentLoading
                            ? "Loading segment data..."
                            : "Loading flyover data..."}
                </p>
              </div>
            </div>
          )}

        {/* ERROR */}
        {(error ||
          movementError ||
          soilError ||
          segmentsError.live ||
          (showDifferenceUI && velocityDiffError)) && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[500] bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg flex items-center gap-2 shadow-lg max-w-md max-[480px]:text-xs max-[480px]:px-3 max-[480px]:py-2 max-[480px]:max-w-[90%]">
              <AlertTriangle
                size={16}
                className="flex-shrink-0 max-[480px]:w-3.5 max-[480px]:h-3.5"
              />
              <span>
                {error ||
                  movementError ||
                  soilError ||
                  segmentsError.live ||
                  (showDifferenceUI && velocityDiffError)}
              </span>
            </div>
          )}

        {/* MOVEMENT CHART */}
        {showChart && selectedPointForChart && selectedDetailForChart && (
          <MovementPointsChart
            pointData={selectedPointForChart}
            detailData={selectedDetailForChart}
            onClose={() => {
              setShowChart(false);
              setSelectedPointForChart(null);
              setSelectedDetailForChart(null);
            }}
          />
        )}

        {/* DIFFERENCE CHART */}
        {showDiffChart && diffPointData && diffDetailData && (
          <MovementDiffChart
            pointData={diffPointData}
            detailData={diffDetailData}
            startDate={diffStartDate}
            endDate={diffEndDate}
            onClose={() => {
              setShowDiffChart(false);
              setDiffPointData(null);
              setDiffDetailData(null);
            }}
          />
        )}
      </div>
    </div>
  );
}

export default LandUseLandCover;
